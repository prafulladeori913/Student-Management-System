<html>
<body>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="sumanta";

$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error){
   die("Connection failed:".$conn>connect_error);
}

$sql="SELECT name,class,adress,photo FROM student";
$result=$conn->query($sql);

if($result[0]->num_rows> 0){
while($row=$result->fetch_assoc()){
   echo "<br>name".$row["name"]."class".$row["class"]."address".$row["address"]."photo".$row["photo"]."<br>";
 }
}else{
   echo "0 results";
}
?>
<table class="table table-bordered">
<tr>
		<th>name</th>
	<th>class</th>
	<th>address</th>
	<th>photo</th>
</tr>
<tr>
<?php $sql="SELECT name,class,address,photo FROM student";
$result=$conn->query($sql);

if($result->num_rows>0){
while($row=$result->fetch_assoc()){
	echo"<td>".$row["name"]."</td>"."<td>".$row["class"]."</td>"."<td>".$row["address"]."</td>"."<td>".$row["photo"]."</td>.</tr>";
  }
}else{
   echo "0 results";
}
?>
</tr>
<?php
$conn->close();
?>

</body>
</html>
	
