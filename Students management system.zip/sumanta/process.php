<?php
include 'database.php';
if(isset($_POST['save']))
{
	$name=$_POST['name'];
	$class=$_POST['class'];
	$address=$_POST['address'];
	$photo=$_POST['photo'];
	$sql="INSERT INTO student(name,class,address,photo)
	values('$name','$class','$address','$photo')";
	if(mysqli_query($conn,$sql)) {
		echo "New record created successfully !";
        }else {
                echo "Error:".$sql."".
   mysqli_error($conn);
		     }
	   mysqli_close($conn);
   }
?>