<?php
$conn=mysqli_connect("localhost", "root", "", "sumanta");
if(isset($_POST["save1"]))
{
	$usr=$_POST["username"];
	$psw=$_POST["password"];

	$res="SELECT * FROM login WHERE UserId='$usr' AND Password='$psw'" or die(mysqli_error()); 
	$result=mysqli_query($conn,$res);
	while($row=mysqli_fetch_assoc($result))
	{
		$uid=$row['UserId'];
		$psw=$row['Password'];
	}
	$count=mysqli_num_rows($result);
	if($count==1)
	{
		echo "Login Successfull";		
		echo "<script>location='menu.html' </script>";
	}
	else
	echo "Invalid login details";
}
?>